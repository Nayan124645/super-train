# Shreeram Wagle — Cinematic Portfolio

React + Vite portfolio for **Shreeram Wagle** (`shreeramwagle.com.np`), combining:
- **6-Second Opening Sequence**: Black screen -> `code`, `profile`, `internet` icons -> `Welcome to my`, `Portfolio Website.`, `shreeramwagle.com.np` -> upward reveal & automatic scroll unlock.
- **Hero + Interactive Physics ID Card**: Left column with `Frontend Developer.` + subtext, and right column with a ~22% scaled Rapier + Three.js + `MeshLine` badge on an `"ID CARD"` strap with a swivel clasp and jump ring, supporting short-pull pendulum swing and long-pull elastic bounce.
- **Scroll-Driven Canvas Frame Sequence (`#sequence`)**: Extracted from `Kimheang01/my-portfolio` (`public/sequence/hero/frame-001.jpg` .. `frame-240.jpg`), placed right after the first hero section as you scroll, with a dedicated **Face / Portrait Slot** ready for your photo (`/images/shreeram-face.jpg`).
- **About, Portfolio Tabs & Contact**: Free-flowing smooth scrolling via Lenis + GSAP `ScrollTrigger` (no section pinning or scroll hijacking).

## Run locally

```bash
npm install
npm run dev
npm run build
```

## Personal assets & GitHub setup

1. Drop your face/portrait image into `public/images/shreeram-face.jpg` and set `FACE_IMAGE_SRC = "/images/shreeram-face.jpg"` in `src/main.jsx`.
2. Add your CV PDF at `public/shreeram-wagle-cv.pdf`.
3. Update `00+` stats, `tabs` items, email (`hello@shreeramwagle.com.np`), and GitHub / LinkedIn links in `src/main.jsx`.
4. Push to GitHub:

```bash
git init
git add .
git commit -m "Add portfolio with scroll frame sequence and interactive ID card"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```


## GitHub Pages deployment

This repository is configured for **Nayan124645/portfolio**.

1. Upload the *contents* of this project folder to the repository root (the root must contain `src/`, `public/`, `index.html`, `package.json`, and `vite.config.js`).
2. Commit and push to the `main` branch.
3. In GitHub, open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
4. Open the **Actions** tab and wait for **Deploy portfolio to GitHub Pages** to finish successfully.

The workflow installs dependencies, runs `npm run build`, and publishes `dist/` automatically. You do not need to run npm on your computer for GitHub to build future pushes.

Expected URL: https://nayan124645.github.io/portfolio/

Do not upload only `index.html`, `package.json`, and `README.md`: the `src/` and `public/` folders are required.
