# Shreeram Wagle Portfolio — final pass

## Included
- Added the supplied monochrome portrait at `public/images/shreeram-face.webp`.
- Connected the portrait to the About section and generated 3D ID-card canvas texture.
- Rebuilt the ID-card face with the supplied name, ID number, department and student label.
- Reworked the intro timeline to explicitly animate all headline text out before the compact particle-like handoff.
- Replaced placeholder Facebook, Instagram and TikTok links with the supplied profile URLs.
- Removed unprovided Threads/GitHub/LinkedIn placeholder destinations.
- Kept the CV action as “CV COMING SOON” until the PDF is supplied.

## Run locally
1. Install Node.js (LTS).
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. For a production build, run `npm run build`.

The CV PDF can later be placed in `public/shreeram-wagle-cv.pdf`, then the CV placeholder can be changed to a download link.
