Place your portrait/face photo at:
  public/images/shreeram-face.jpg

Then in src/main.jsx, set FACE_IMAGE_SRC = '/images/shreeram-face.jpg' (or set it in the ScrollSequenceSection / About portrait slot) to display your photo.
