import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  // GitHub Pages project site: https://nayan124645.github.io/portfolio/
  base: '/portfolio/',
  plugins: [react()],
});
