import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import * as THREE from 'three';
import { Canvas, extend, useFrame, useThree } from '@react-three/fiber';
import { BallCollider, CuboidCollider, Physics, RigidBody, useRopeJoint, useSphericalJoint } from '@react-three/rapier';
import { MeshLineGeometry, MeshLineMaterial } from 'meshline';
import { Code2, UserRound, Globe2, ArrowUpRight, ArrowDown, Github, Linkedin, Mail, MoveUpRight, Menu, X, Facebook, Instagram, AtSign, Music2, ArrowLeft } from 'lucide-react';
import Lenis from '@studio-freight/lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import './styles.css';

gsap.registerPlugin(ScrollTrigger);
extend({ MeshLineGeometry, MeshLineMaterial });

// Drop your face photo at public/images/shreeram-face.jpg and set FACE_IMAGE_SRC = '/images/shreeram-face.jpg'
const BASE_URL = import.meta.env.BASE_URL;
const FACE_IMAGE_SRC = `${BASE_URL}images/shreeram-face.webp`;

const SEQUENCE_CONFIG = {
  frameCount: 240,
  frameUrl: (index) => `${BASE_URL}sequence/hero/frame-${String(index).padStart(3, '0')}.jpg`,
};

function makeBadgeTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 1000; canvas.height = 1400;
  const ctx = canvas.getContext('2d');
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const draw = () => {
    ctx.fillStyle = '#efefed'; ctx.fillRect(0, 0, 1000, 1400);
    ctx.strokeStyle = '#b8b8b5'; ctx.lineWidth = 5; ctx.strokeRect(24, 24, 952, 1352);
    // Header band and slot
    ctx.fillStyle = '#d6d6d3'; ctx.fillRect(28, 28, 944, 250);
    ctx.fillStyle = '#b8b8b5'; ctx.beginPath(); ctx.roundRect(390, 48, 220, 42, 21); ctx.fill();
    ctx.fillStyle = '#171717'; ctx.font = '900 62px Arial'; ctx.textAlign = 'center'; ctx.fillText('SHREERAM WAGLE', 500, 190);
    ctx.font = '600 30px Arial'; ctx.fillText('IDENTITY  /  PORTFOLIO', 500, 240);
    // Portrait window
    ctx.fillStyle = '#fafaf8'; ctx.fillRect(250, 310, 500, 500);
    ctx.strokeStyle = '#8b8b88'; ctx.lineWidth = 8; ctx.strokeRect(250, 310, 500, 500);
    const finish = () => {
      ctx.textAlign = 'center'; ctx.fillStyle = '#101010'; ctx.font = '900 66px Arial'; ctx.fillText('SHREERAM WAGLE', 500, 920);
      ctx.font = '600 30px Arial'; ctx.fillText('FRONTEND DEVELOPER', 500, 978);
      ctx.textAlign = 'left'; ctx.font = '700 34px Arial'; ctx.fillText('ID NO:', 80, 1100);
      ctx.font = '500 42px Arial'; ctx.fillText('124645', 220, 1100);
      ctx.font = '700 34px Arial'; ctx.fillText('DEPT:', 80, 1170);
      ctx.font = '500 34px Arial'; ctx.fillText('FRONTEND DEV', 220, 1170);
      // Decorative QR-like matrix, deliberately not a credential/URL.
      const qx = 790, qy = 1040, cell = 12;
      ctx.fillStyle = '#111';
      for (let y=0; y<21; y++) for (let x=0; x<21; x++) {
        const finder = (ox,oy) => x>=ox && x<ox+7 && y>=oy && y<oy+7;
        let on = ((x*7+y*11+x*y)%5 < 2) || ((x+y)%7===0);
        if (finder(0,0) || finder(14,0) || finder(0,14)) {
          const ox = x>=14?14:0, oy = y>=14?14:0, dx=x-ox, dy=y-oy;
          on = dx===0 || dx===6 || dy===0 || dy===6 || (dx>=2&&dx<=4&&dy>=2&&dy<=4);
        }
        if (on) ctx.fillRect(qx+x*cell,qy+y*cell,cell-2,cell-2);
      }
      ctx.fillStyle = '#202020'; ctx.fillRect(28, 1290, 944, 82);
      ctx.fillStyle = '#f2f2f0'; ctx.font = '700 36px Arial'; ctx.textAlign = 'left'; ctx.fillText('STUDENT', 78, 1345);
      ctx.textAlign = 'right'; ctx.font = '22px monospace'; ctx.fillText('NEPAL  ·  2026', 920, 1345);
      texture.needsUpdate = true;
    };
    const photo = new Image();
    photo.onload = () => {
      ctx.save(); ctx.beginPath(); ctx.rect(258, 318, 484, 484); ctx.clip();
      const scale = Math.max(484/photo.width, 484/photo.height);
      const w=photo.width*scale, h=photo.height*scale;
      ctx.filter='grayscale(1) contrast(1.08)'; ctx.drawImage(photo, 258+(484-w)/2, 318+(484-h)/2, w, h);
      ctx.restore(); finish();
    };
    photo.onerror = finish;
    photo.src = FACE_IMAGE_SRC;
  };
  draw();
  return texture;
}
function makeStrapTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#1b1b1b';
  ctx.fillRect(0, 0, 512, 128);

  ctx.fillStyle = 'rgba(255,255,255,0.04)';
  for (let x = 0; x < 512; x += 6) {
    ctx.fillRect(x, 0, 2, 128);
  }

  ctx.strokeStyle = 'rgba(255,255,255,0.22)';
  ctx.lineWidth = 3;
  ctx.setLineDash([10, 6]);
  ctx.beginPath();
  ctx.moveTo(0, 12);
  ctx.lineTo(512, 12);
  ctx.moveTo(0, 116);
  ctx.lineTo(512, 116);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.fillStyle = '#e8e8e6';
  ctx.font = '700 40px "DM Mono", monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('ID CARD', 132, 66);
  ctx.fillStyle = '#7c7c7c';
  ctx.fillText('•', 256, 65);
  ctx.fillStyle = '#e8e8e6';
  ctx.fillText('ID CARD', 380, 66);
  ctx.fillStyle = '#7c7c7c';
  ctx.fillText('•', 504, 65);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.repeat.set(1, 1);
  texture.anisotropy = 8;
  return texture;
}

function PhysicsBadge() {
  const band = useRef();
  const claspRef = useRef();
  const fixed = useRef(); const j1 = useRef(); const j2 = useRef(); const j3 = useRef(); const card = useRef();
  const dragOffset = useMemo(() => new THREE.Vector3(), []);
  const dragPlane = useMemo(() => new THREE.Plane(new THREE.Vector3(0, 0, 1), 0), []);
  const hit = useMemo(() => new THREE.Vector3(), []);
  const raycaster = useMemo(() => new THREE.Raycaster(), []);
  const restPos = useMemo(() => new THREE.Vector3(0, -2.6, 0), []);
  const currentCardPos = useMemo(() => new THREE.Vector3(), []);
  const claspDir = useMemo(() => new THREE.Vector3(), []);
  const upVec = useMemo(() => new THREE.Vector3(0, 1, 0), []);
  const { width, height } = useThree((s) => s.size);
  const [curve] = useState(() => new THREE.CatmullRomCurve3(Array.from({ length: 8 }, () => new THREE.Vector3()), false, 'centripetal'));
  const [dragged, setDragged] = useState(false);
  const maxStretchRef = useRef(0);
  const texture = useMemo(makeBadgeTexture, []);
  const strapTexture = useMemo(makeStrapTexture, []);

  useRopeJoint(fixed, j1, [[0, 0, 0], [0, 0, 0], 0.5]);
  useRopeJoint(j1, j2, [[0, 0, 0], [0, 0, 0], 0.5]);
  useRopeJoint(j2, j3, [[0, 0, 0], [0, 0, 0], 0.5]);
  useSphericalJoint(j3, card, [[0, 0, 0], [0, 1.24, 0]]);

  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.033);

    if (dragged && card.current) {
      raycaster.setFromCamera(state.pointer, state.camera);
      if (raycaster.ray.intersectPlane(dragPlane, hit)) {
        const target = hit.clone().sub(dragOffset);
        const pullVec = target.clone().sub(restPos);
        const pullDist = pullVec.length();
        const softMax = 3.6;
        if (pullDist > softMax) {
          const excess = pullDist - softMax;
          const dampedDist = softMax + Math.tanh(excess * 0.55) * 1.35;
          target.copy(restPos).add(pullVec.normalize().multiplyScalar(dampedDist));
        }
        maxStretchRef.current = Math.max(maxStretchRef.current, pullDist);
        card.current.setNextKinematicTranslation({ x: target.x, y: target.y, z: target.z });
      }
    }

    if (fixed.current && card.current && j1.current && j2.current && j3.current) {
      const p0 = fixed.current.translation();
      const p1 = j1.current.translation();
      const p2 = j2.current.translation();
      const p3 = j3.current.translation();
      const p4 = card.current.translation();

      const cardRot = card.current.rotation();
      const q = new THREE.Quaternion(cardRot.x, cardRot.y, cardRot.z, cardRot.w);
      const ringTopWorld = new THREE.Vector3(0, 1.36, 0).applyQuaternion(q).add(new THREE.Vector3(p4.x, p4.y, p4.z));

      curve.points[0].set(p0.x, p0.y, p0.z);
      curve.points[1].set(p0.x * 0.72 + p1.x * 0.28, p0.y * 0.72 + p1.y * 0.28, (p0.z + p1.z) * 0.5);
      curve.points[2].set(p1.x, p1.y, p1.z);
      curve.points[3].set(p2.x, p2.y, p2.z);
      curve.points[4].set(p3.x, p3.y, p3.z);
      curve.points[5].set((p3.x + ringTopWorld.x) * 0.5, (p3.y + ringTopWorld.y) * 0.5 + 0.04, (p3.z + ringTopWorld.z) * 0.5);
      curve.points[6].set(ringTopWorld.x, ringTopWorld.y + 0.06, ringTopWorld.z);
      curve.points[7].set(ringTopWorld.x, ringTopWorld.y + 0.02, ringTopWorld.z);
      band.current.geometry.setPoints(curve.getPoints(64));

      if (claspRef.current) {
        claspDir.set(p3.x - ringTopWorld.x, p3.y - ringTopWorld.y, p3.z - ringTopWorld.z);
        if (claspDir.lengthSq() > 0.0001) {
          claspDir.normalize();
          claspRef.current.quaternion.setFromUnitVectors(upVec, claspDir);
        }
      }

      if (!dragged) {
        const ang = card.current.angvel();
        card.current.setAngvel({
          x: ang.x * 0.985,
          y: ang.y - cardRot.y * 0.22,
          z: ang.z * 0.992
        }, true);

        currentCardPos.set(p4.x, p4.y, p4.z);
        const verticalExtension = restPos.y - currentCardPos.y;
        if (verticalExtension > 0.25) {
          const lin = card.current.linvel();
          const springBoost = Math.min(verticalExtension * 18 * dt, 6.5);
          card.current.setLinvel({
            x: lin.x,
            y: lin.y + springBoost,
            z: lin.z
          }, true);
        }
      }
    }
  });

  const beginDrag = (e) => {
    e.stopPropagation();
    if (!card.current) return;
    e.target.setPointerCapture?.(e.pointerId);
    maxStretchRef.current = 0;
    dragOffset.copy(e.point).sub(card.current.translation());
    [card, j1, j2, j3, fixed].forEach((ref) => ref.current?.wakeUp());
    setDragged(true);
  };

  const endDrag = (e) => {
    e.stopPropagation();
    e.target.releasePointerCapture?.(e.pointerId);

    if (card.current) {
      const p4 = card.current.translation();
      const currentStretch = new THREE.Vector3(p4.x, p4.y, p4.z).distanceTo(restPos);
      const peakStretch = Math.max(currentStretch, maxStretchRef.current);

      if (peakStretch >= 1.15) {
        const recoilVec = restPos.clone().sub(new THREE.Vector3(p4.x, p4.y, p4.z));
        recoilVec.normalize();
        const intensity = Math.min((peakStretch - 0.9) * 4.4, 11.5);

        card.current.setLinvel({
          x: recoilVec.x * intensity * 0.95,
          y: Math.max(recoilVec.y * intensity, intensity * 0.65),
          z: recoilVec.z * intensity * 0.45
        }, true);

        card.current.setAngvel({
          x: (Math.random() - 0.5) * 1.4,
          y: recoilVec.x * 2.2,
          z: -recoilVec.x * 2.6
        }, true);

        [j1, j2, j3].forEach((jRef, idx) => {
          jRef.current?.wakeUp();
          jRef.current?.setLinvel({
            x: recoilVec.x * intensity * (0.35 + idx * 0.15),
            y: intensity * (0.3 + idx * 0.12),
            z: 0
          }, true);
        });
      }
    }

    maxStretchRef.current = 0;
    setDragged(false);
  };

  return <>
    <group position={[0, 3.05, 0]}>
      <RigidBody ref={fixed} type="fixed" />
      <RigidBody ref={j1} position={[0, -0.5, 0]} angularDamping={1.6} linearDamping={1.4}><BallCollider args={[0.055]} /></RigidBody>
      <RigidBody ref={j2} position={[0, -1.0, 0]} angularDamping={1.6} linearDamping={1.4}><BallCollider args={[0.055]} /></RigidBody>
      <RigidBody ref={j3} position={[0, -1.5, 0]} angularDamping={1.6} linearDamping={1.4}><BallCollider args={[0.06]} /></RigidBody>
      <RigidBody ref={card} position={[0, -2.6, 0]} angularDamping={1.45} linearDamping={1.25} restitution={0.45} type={dragged ? 'kinematicPosition' : 'dynamic'}>
        <CuboidCollider args={[0.84, 1.15, 0.075]} />
        <mesh onPointerUp={endDrag} onPointerCancel={endDrag} onPointerDown={beginDrag} castShadow receiveShadow>
          <boxGeometry args={[1.68, 2.3, 0.11]} />
          <meshStandardMaterial color="#151515" roughness={0.38} metalness={0.24} />
        </mesh>
        <mesh position={[0, 0, 0.061]} onPointerUp={endDrag} onPointerCancel={endDrag} onPointerDown={beginDrag}>
          <planeGeometry args={[1.66, 2.28]} />
          <meshBasicMaterial map={texture} toneMapped={false} />
        </mesh>
        <mesh position={[0, 0, -0.061]} rotation={[0, Math.PI, 0]} onPointerUp={endDrag} onPointerCancel={endDrag} onPointerDown={beginDrag}>
          <planeGeometry args={[1.66, 2.28]} />
          <meshStandardMaterial color="#101010" roughness={0.55} metalness={0.2} />
        </mesh>

        {/* Reinforced card eyelet: a low-profile metal grommet fixed to the card. */}
        <mesh position={[0, 1.105, 0.012]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.082, 0.082, 0.035, 32]} />
          <meshStandardMaterial color="#343434" metalness={0.88} roughness={0.3} />
        </mesh>
        <mesh position={[0, 1.105, 0.034]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.055, 0.012, 10, 32]} />
          <meshStandardMaterial color="#c8c8c8" metalness={0.95} roughness={0.2} />
        </mesh>

        {/* Small swivel snap hook. Its closed lower eye passes through the card eyelet. */}
        <group position={[0, 1.17, 0.015]} ref={claspRef}>
          <mesh position={[0, 0.005, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.061, 0.012, 10, 28]} />
            <meshStandardMaterial color="#d0d0d0" metalness={0.96} roughness={0.18} />
          </mesh>
          <mesh position={[0, 0.075, 0]}>
            <cylinderGeometry args={[0.018, 0.022, 0.09, 16]} />
            <meshStandardMaterial color="#aeb0b2" metalness={0.95} roughness={0.2} />
          </mesh>
          <mesh position={[0, 0.145, 0]}>
            <torusGeometry args={[0.047, 0.011, 10, 28, Math.PI * 1.68]} />
            <meshStandardMaterial color="#d7d7d7" metalness={0.96} roughness={0.18} />
          </mesh>
          <mesh position={[0.039, 0.125, 0]} rotation={[0, 0, -0.45]}>
            <cylinderGeometry args={[0.006, 0.006, 0.055, 8]} />
            <meshStandardMaterial color="#eeeeee" metalness={0.95} roughness={0.18} />
          </mesh>
        </group>
      </RigidBody>
    </group>
    <mesh ref={band}>
      <meshLineGeometry />
      <meshLineMaterial
        useMap={1}
        map={strapTexture}
        transparent
        opacity={0.98}
        color="#ffffff"
        depthTest={true}
        resolution={[width, height]}
        lineWidth={2.0}
      />
    </mesh>
  </>;
}

function HangingCard() {
  return <div className="id-wrap" aria-label="Interactive physics ID card. Drag with mouse or touch to swing it.">
    <Canvas camera={{ position: [0, 0, 15.8], fov: 25 }} dpr={[1, 1.75]} gl={{ alpha: true, antialias: true, powerPreference: 'high-performance' }}>
      <ambientLight intensity={1.7} /><directionalLight position={[4, 6, 8]} intensity={2.5} /><directionalLight position={[-4, 1, 3]} intensity={0.65} />
      <Physics gravity={[0, -24, 0]} timeStep={1 / 60}><PhysicsBadge /></Physics>
    </Canvas>
    <p className="drag-note">DRAG TO INTERACT <span>↗</span></p>
  </div>;
}

/* Extracted 240-frame scroll-driven canvas sequence from my-portfolio, placed after #home hero */
function ScrollSequenceSection() {
  const sectionRef = useRef(null);
  const canvasRef = useRef(null);
  const [frameIndex, setFrameIndex] = useState(1);
  const [progressPct, setProgressPct] = useState(0);

  useEffect(() => {
    const section = sectionRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!section || !canvas || !ctx) return;

    const images = Array.from({ length: SEQUENCE_CONFIG.frameCount }, (_, i) => {
      const img = new Image();
      img.src = SEQUENCE_CONFIG.frameUrl(i + 1);
      return img;
    });

    const animState = { frame: 0 };

    const drawFrame = () => {
      let idx = Math.round(animState.frame);
      idx = Math.max(0, Math.min(images.length - 1, idx));
      let fallback = idx;
      while (fallback > 0 && !(images[fallback].complete && images[fallback].naturalWidth > 0)) {
        fallback--;
      }
      const img = images[fallback];
      if (!img || !img.complete || img.naturalWidth === 0) return;

      const { width, height } = canvas;
      const scale = Math.max(width / img.naturalWidth, height / img.naturalHeight);
      const w = img.naturalWidth * scale;
      const h = img.naturalHeight * scale;
      ctx.clearRect(0, 0, width, height);
      ctx.drawImage(img, (width - w) / 2, (height - h) / 2, w, h);
    };

    const resizeCanvas = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const cw = canvas.clientWidth || 640;
      const ch = canvas.clientHeight || 420;
      canvas.width = Math.round(cw * dpr);
      canvas.height = Math.round(ch * dpr);
      drawFrame();
    };

    images.forEach((img, i) => {
      img.addEventListener('load', () => {
        if (i <= Math.round(animState.frame)) drawFrame();
      }, { once: true });
    });

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const gsapCtx = gsap.context(() => {
      gsap.to(animState, {
        frame: SEQUENCE_CONFIG.frameCount - 1,
        ease: 'none',
        scrollTrigger: {
          trigger: section,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 0.6,
          onUpdate: (self) => {
            drawFrame();
            const current = Math.max(1, Math.min(SEQUENCE_CONFIG.frameCount, Math.round(animState.frame) + 1));
            setFrameIndex(current);
            setProgressPct(Math.round(self.progress * 100));
          }
        }
      });
    }, section);

    return () => {
      gsapCtx.revert();
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  return (
    <section className="scroll-sequence" id="sequence" ref={sectionRef}>
      <div className="section-kicker reveal">
        <span>01B — MOTION SEQUENCE</span>
        <span>SCROLL-DRIVEN FRAME CANVAS</span>
      </div>
      <div className="sequence-stage reveal">
        <div className="sequence-canvas-wrap">
          <canvas ref={canvasRef} className="sequence-canvas" aria-label="Scroll-driven 240-frame visual sequence" />
          <div className="sequence-vignette" />
          <div className="sequence-overlay">
            <div>
              <p className="sequence-eyebrow">SHREERAM WAGLE · INTERACTIVE FRAME STREAM</p>
              <h2 className="sequence-title">Motion in <span>sequence.</span></h2>
              <p className="sequence-copy">
                As you scroll past the hero, 240 frames scrub smoothly across the canvas — bridging the opening badge interaction with your story and work.
              </p>
            </div>
            <div className="sequence-meta">
              <span>FRAME {String(frameIndex).padStart(3, '0')} / {SEQUENCE_CONFIG.frameCount}</span>
              <div className="sequence-bar"><div className="sequence-bar-fill" style={{ width: `${progressPct}%` }} /></div>
              <span>{progressPct}%</span>
            </div>
          </div>
        </div>

        <aside className="sequence-face-panel sequence-dev-panel" aria-label="Development environment preview">
          <div className="face-slot-label">
            <span>DEVELOPMENT ENVIRONMENT</span>
            <span>CONNECTED</span>
          </div>
          <div className="dev-preview">
            <div className="dev-preview-head"><Code2 size={15}/><span>src / App.jsx</span><span>JSX</span></div>
            <div className="dev-preview-code">
              <p><i>01</i><b>const</b> experience = {'{'}</p>
              <p><i>02</i>&nbsp; design: <strong>'intentional'</strong>,</p>
              <p><i>03</i>&nbsp; motion: <strong>'fluid'</strong>,</p>
              <p><i>04</i>&nbsp; performance: <strong>'optimized'</strong>,</p>
              <p><i>05</i>{'}'};</p>
              <p className="dev-preview-comment"><i>06</i>// building something meaningful_</p>
            </div>
            <div className="dev-preview-footer"><span><i/> SYSTEM READY</span><span>UTF-8&nbsp; · &nbsp;LF</span></div>
          </div>
          <div className="sequence-meta">
            <span>SHREERAM WAGLE</span>
            <span>NEPAL</span>
          </div>
        </aside>
      </div>
    </section>
  );
}

function Intro() {
  const intro = useRef(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    document.body.classList.remove('intro-ready');
    document.documentElement.classList.remove('intro-ready');
    delete document.body.dataset.introComplete;
    window.scrollTo(0, 0);

    const ctx = gsap.context(() => {
      gsap.set('.intro-code-window', { opacity: 0, y: 42, rotateX: 12, rotateY: -7, scale: .92, filter: 'blur(12px)', transformPerspective: 1200 });
      gsap.set('.intro-copy', { opacity: 0, y: 24, scale: .96, filter: 'blur(8px)' });
      gsap.set('.intro-line-one', { clipPath: 'inset(0 100% 0 0)', x: -24 });
      gsap.set('.intro-line-two', { clipPath: 'inset(0 0 0 100%)', x: 28 });
      gsap.set('.intro-domain', { opacity: 0, letterSpacing: '.28em', y: 14 });
      gsap.set('.intro-hint', { opacity: 0, y: 14 });
      gsap.set('.intro-index', { opacity: 0, x: -12 });
      gsap.set('.code-line', { opacity: 0, x: -18, filter: 'blur(4px)' });
      gsap.set('.intro-code-window', { transformOrigin: '50% 55%' });

      const tl = gsap.timeline({
        defaults: { ease: 'power3.out' },
        onComplete: () => {
          document.body.classList.add('intro-ready');
          document.documentElement.classList.add('intro-ready');
          document.body.dataset.introComplete = 'true';
          setDone(true);
          window.dispatchEvent(new Event('portfolio:intro-ready'));
          ScrollTrigger.refresh();
        }
      });

      // Apple-like editorial reveal, explicit text exits, then a single-point swarm handoff.
      tl.to('.intro-code-window', { opacity: 1, y: 0, rotateX: 0, rotateY: 0, scale: 1, filter: 'blur(0px)', duration: .95, ease: 'power4.out' }, .1)
        .fromTo('.code-window-top', { clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0% 0 0)', duration: .55, ease: 'power3.inOut' }, .35)
        .to('.code-line', { opacity: 1, x: 0, filter: 'blur(0px)', stagger: .065, duration: .32, ease: 'power2.out' }, .55)
        .to('.intro-copy', { opacity: 1, y: 0, scale: 1, filter: 'blur(0px)', duration: .7, ease: 'power3.out' }, 1.65)
        .to('.intro-line-one', { clipPath: 'inset(0 0% 0 0)', x: 0, duration: .65, ease: 'power4.inOut' }, 1.78)
        .to('.intro-line-two', { clipPath: 'inset(0 0% 0 0)', x: 0, duration: .78, ease: 'power4.inOut' }, 2.0)
        .to('.intro-domain', { opacity: 1, letterSpacing: '.08em', y: 0, duration: .55, ease: 'power3.out' }, 2.75)
        .to('.intro-hint', { opacity: 1, y: 0, duration: .45 }, 3.25)
        .to('.intro-index', { opacity: 1, x: 0, duration: .4 }, 3.2)
        // All visible copy and code leave the stage before the transition completes.
        .to('.intro-hint, .intro-index', { opacity: 0, y: -12, duration: .28, ease: 'power2.in' }, 4.45)
        .to('.intro-line-one', { y: -70, opacity: 0, filter: 'blur(10px)', duration: .48, ease: 'power3.in' }, 4.5)
        .to('.intro-line-two', { y: 85, opacity: 0, filter: 'blur(14px)', scale: .94, duration: .55, ease: 'power3.in' }, 4.52)
        .to('.intro-domain', { y: 24, opacity: 0, letterSpacing: '.3em', duration: .35, ease: 'power2.in' }, 4.55)
        .to('.intro-code-window', { x: 0, y: 0, rotateX: 0, rotateY: 0, rotateZ: 0, scale: .035, opacity: 0, filter: 'blur(16px)', duration: .72, ease: 'power4.in' }, 4.72)
        .to('.intro-swarm', { opacity: 1, scale: 1, filter: 'blur(0px)', duration: .42, ease: 'power3.out' }, 5.05)
        .to('.intro-swarm', { scale: 24, opacity: 0, filter: 'blur(8px)', duration: .72, ease: 'power4.in' }, 5.52)
        .to(intro.current, { clipPath: 'inset(0 0 100% 0)', duration: .72, ease: 'power4.inOut' }, 5.72);
      tl.duration(6.5);
    }, intro);

    return () => ctx.revert();
  }, []);

  if (done) return null;
  return (
    <section className="intro" ref={intro} id="top" aria-label="Intro sequence">
      <div className="intro-inner">
        <div className="intro-code-window" aria-label="Source code visual">
          <div className="code-window-top"><div className="code-window-dots"><i /><i /><i /></div><span>nxt-core / portfolio.jsx</span><span className="code-window-status">● LIVE</span></div>
          <div className="code-window-body">
            <div className="code-line"><span>01</span><b className="syntax-purple">import</b> <em>React</em> <b className="syntax-purple">from</b> <strong>'react'</strong>;</div>
            <div className="code-line"><span>02</span><b className="syntax-purple">const</b> <em>Portfolio</em> = () <b className="syntax-purple">=&gt;</b> {'{'}</div>
            <div className="code-line"><span>03</span>&nbsp;&nbsp;<b className="syntax-blue">return</b> (</div>
            <div className="code-line"><span>04</span>&nbsp;&nbsp;&nbsp;&nbsp;<b className="syntax-green">&lt;CreativeExperience</b></div>
            <div className="code-line"><span>05</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;motion=<strong>"cinematic"</strong></div>
            <div className="code-line"><span>06</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;detail=<strong>"every-pixel"</strong></div>
            <div className="code-line"><span>07</span>&nbsp;&nbsp;&nbsp;&nbsp;<b className="syntax-green">/&gt;</b></div>
            <div className="code-line"><span>08</span>&nbsp;&nbsp;);</div>
            <div className="code-line"><span>09</span>{'}'};</div>
          </div>
        </div>
        <div className="intro-swarm" aria-hidden="true" />
        <div className="intro-copy">
          <div className="line-mask"><p className="intro-line intro-line-one">Welcome to my</p></div>
          <div className="line-mask"><h1 className="intro-line intro-line-two">Portfolio Website<span>.</span></h1></div>
          <div className="line-mask"><p className="intro-line intro-domain">shreeramwagle.com.np</p></div>
        </div>
        <div className="intro-hint"><span>INITIALIZING EXPERIENCE</span><ArrowDown size={15} /></div>
      </div>
      <div className="intro-index">SW — 001</div>
    </section>
  );
}

function StoryPage({ onBack }) {
  return <main className="story-page">
    <nav className="story-nav"><a className="brand" href="#home" onClick={(e) => { e.preventDefault(); onBack(); }}>shreeramwagle<span>.com.np</span></a><button className="story-back" onClick={onBack}><ArrowLeft size={15}/> BACK TO HOME</button></nav>
    <section className="story-hero">
      <p className="eyebrow">A LITTLE MORE ABOUT ME · 01</p>
      <h1>Beyond the<br/><em>interface.</em></h1>
      <p>This is where my personal introduction will live — a dedicated space for my story, perspective, and the motion sequence we're building next.</p>
      <div className="story-placeholder"><Code2 size={22}/><span>PERSONAL INTRODUCTION</span><strong>MOTION SEQUENCE COMING NEXT</strong><i/></div>
    </section>
  </main>;
}

function App() {
  const [activeTab, setActiveTab] = useState('projects');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [storyPage, setStoryPage] = useState(window.location.hash === '#/story');
  useEffect(() => {
    const syncRoute = () => setStoryPage(window.location.hash === '#/story');
    window.addEventListener('hashchange', syncRoute);
    return () => window.removeEventListener('hashchange', syncRoute);
  }, []);
  useEffect(() => {
    const lenis = new Lenis({ duration: 1.1, smoothWheel: true, wheelMultiplier: 0.9, touchMultiplier: 1.35, anchors: true });
    window.__portfolioLenis = lenis;
    lenis.scrollTo(0, { immediate: true });
    if (document.body.dataset.introComplete !== 'true') lenis.stop();
    const startScrolling = () => {
      lenis.scrollTo(0, { immediate: true });
      lenis.start();
    };
    window.addEventListener('portfolio:intro-ready', startScrolling);
    const onScroll = () => ScrollTrigger.update();
    lenis.on('scroll', onScroll);
    const ticker = (time) => lenis.raf(time * 1000);
    gsap.ticker.add(ticker); gsap.ticker.lagSmoothing(0);
    const ctx = gsap.context(() => {
      gsap.utils.toArray('.reveal').forEach((el) => gsap.fromTo(el, { y: 40, opacity: 0 }, { y: 0, opacity: 1, duration: 0.9, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 86%', toggleActions: 'play none none reverse' } }));
    });
    const refresh = window.setTimeout(() => ScrollTrigger.refresh(), 250);
    return () => { window.clearTimeout(refresh); window.removeEventListener('portfolio:intro-ready', startScrolling); delete window.__portfolioLenis; ctx.revert(); lenis.off('scroll', onScroll); gsap.ticker.remove(ticker); lenis.destroy(); };
  }, []);
  const closeMenu = () => setMobileOpen(false);
  const openStory = (e) => { e.preventDefault(); window.location.hash = '/story'; setStoryPage(true); window.scrollTo(0, 0); };
  const backHome = () => { window.location.hash = '/home'; setStoryPage(false); window.scrollTo(0, 0); };
  const tabs = {
    projects: [{ n: '01', title: 'Project One', sub: 'Web development · Placeholder', cls: 'visual-one', graphic: <>PROJECT<br />PREVIEW</> }, { n: '02', title: 'Project Two', sub: 'Creative coding · Placeholder', cls: 'visual-two', graphic: <>INTO<br />MOTION</> }, { n: '03', title: 'Project Three', sub: 'Experiment · Placeholder', cls: 'visual-three', graphic: <>MORE<br />SOON</> }],
    certificates: [{ n: '01', title: 'Certificate One', sub: 'Course / Issuer · Placeholder', cls: 'visual-one', graphic: <>CERTIFICATE<br />01</> }, { n: '02', title: 'Certificate Two', sub: 'Course / Issuer · Placeholder', cls: 'visual-two', graphic: <>CERTIFICATE<br />02</> }, { n: '03', title: 'Certificate Three', sub: 'Course / Issuer · Placeholder', cls: 'visual-three', graphic: <>CERTIFICATE<br />03</> }],
    stack: [{ n: '01', title: 'Frontend', sub: 'HTML · CSS · JavaScript', cls: 'visual-one', graphic: <>HTML<br />CSS / JS</> }, { n: '02', title: 'Frameworks', sub: 'React · Vite', cls: 'visual-two', graphic: <>REACT<br />VITE</> }, { n: '03', title: 'Tools', sub: 'Git · GitHub · VS Code', cls: 'visual-three', graphic: <>GIT<br />TOOLS</> }]
  };
  return <><Intro />{storyPage ? <StoryPage onBack={backHome} /> : <main>
    <section className="hero section-shell" id="home"><nav className="nav"><a className="brand" href="#home">shreeramwagle<span>.com.np</span></a><div className={`nav-links ${mobileOpen ? 'open' : ''}`}><a onClick={closeMenu} href="#home">Home</a><a onClick={closeMenu} href="#sequence">Sequence</a><a onClick={closeMenu} href="#about">About</a><a onClick={closeMenu} href="#portfolio">Portfolio</a><a onClick={closeMenu} href="#contact">Contact <ArrowUpRight size={13} /></a></div><button className="menu-btn" onClick={() => setMobileOpen((v) => !v)} aria-label="Toggle navigation">{mobileOpen ? <X size={17} /> : <Menu size={17} />} <span>{mobileOpen ? 'CLOSE' : 'MENU'}</span></button></nav>
      <div className="hero-grid">
        <div className="hero-left">
          <div className="availability"><i /> AVAILABLE FOR WORK</div>
          <p className="eyebrow">HELLO, I'M SHREERAM</p>
          <h2>Frontend<br />Developer<span>.</span></h2>
          <p className="hero-desc">Crafting clean, interactive web experiences with modern code, motion, and attention to detail.</p>
          <a className="text-link" href="#/story" onClick={openStory}>GET TO KNOW ME <MoveUpRight size={15} /></a>
          <div className="hero-meta"><span>BASED IN NEPAL</span><span>OPEN TO OPPORTUNITIES</span></div>
        </div>
        <HangingCard />
      </div>
      <div className="hero-bottom"><span>SCROLL TO DISCOVER</span><div className="scroll-line" /><span>01 / 04</span></div>
    </section>

    <ScrollSequenceSection />

    <section className="about section-shell" id="about"><div className="section-kicker reveal"><span>02 — A LITTLE ABOUT ME</span><span>GET TO KNOW THE PERSON BEHIND THE CODE</span></div><div className="about-grid"><div className="about-copy reveal"><p className="eyebrow">WHO I AM</p><h2>Curious mind.<br />Creative <em>builder.</em></h2><p className="body-copy">I'm Shreeram, a frontend developer and programmer passionate about creating useful, expressive experiences for the web. I enjoy exploring how design and technology come together — and I'm always working to make the next thing better than the last.</p><div className="about-actions"><span className="pill-button cv-pending" aria-label="CV will be added later">CV COMING SOON</span><a className="pill-button light" href="#portfolio">VIEW PROJECTS <ArrowUpRight size={16} /></a></div></div><div className="portrait-wrap reveal"><div className="portrait"><div className="portrait-placeholder">{FACE_IMAGE_SRC ? <img src={FACE_IMAGE_SRC} alt="Shreeram Wagle" className="portrait-img" /> : <><UserRound size={92} strokeWidth={0.8} /><span>YOUR PHOTO HERE</span></>}</div></div><span className="portrait-caption">SHREERAM WAGLE · DEVELOPER</span></div></div><div className="stats reveal"><div><strong>00<span>+</span></strong><span>PROJECTS</span></div><div><strong>00<span>+</span></strong><span>CERTIFICATES</span></div><div><strong>00<span>+</span></strong><span>COMPLETED WORKS</span></div></div></section>
    <section className="portfolio section-shell" id="portfolio"><div className="section-kicker reveal"><span>03 — SELECTED WORK</span><span>A FEW THINGS I'VE BEEN WORKING ON</span></div><div className="portfolio-heading reveal"><p className="eyebrow">THE GOOD STUFF</p><h2>Portfolio<span>.</span></h2><p>Ideas, experiments, and things made with intention.</p></div><div className="portfolio-tabs reveal"><button className={activeTab === 'projects' ? 'active' : ''} onClick={() => setActiveTab('projects')}>01 / PROJECTS</button><button className={activeTab === 'certificates' ? 'active' : ''} onClick={() => setActiveTab('certificates')}>02 / CERTIFICATES</button><button className={activeTab === 'stack' ? 'active' : ''} onClick={() => setActiveTab('stack')}>03 / TECH STACK</button></div><div className="project-grid reveal">{tabs[activeTab].map((item) => <article className="project-card" key={`${activeTab}-${item.n}`}><div className={`project-visual ${item.cls}`}><span>{item.n}</span><div className="visual-type">{item.graphic}</div><ArrowUpRight /></div><div className="project-info"><div><h3>{item.title}</h3><p>{item.sub}</p></div><ArrowUpRight /></div></article>)}</div></section>
    <section className="social-section section-shell" id="socials"><div className="section-kicker reveal"><span>04 — FIND ME ELSEWHERE</span><span>LET’S CONNECT OUTSIDE THE PORTFOLIO</span></div><div className="social-heading reveal"><p className="eyebrow">AROUND THE INTERNET</p><h2>Stay <em>connected.</em></h2><p>Follow along, see what I’m creating, and keep in touch.</p></div><div className="social-grid reveal"><a className="social-card" href="https://www.facebook.com/nayan.wagle.2025" target="_blank" rel="noreferrer"><Facebook/><span>FACEBOOK</span><small>nayan.wagle.2025</small><ArrowUpRight/></a><a className="social-card" href="https://www.tiktok.com/@nocetra.cc" target="_blank" rel="noreferrer"><Music2/><span>TIKTOK</span><small>@nocetra.cc</small><ArrowUpRight/></a><a className="social-card" href="https://www.instagram.com/krazyy.nayan/" target="_blank" rel="noreferrer"><Instagram/><span>INSTAGRAM</span><small>@krazyy.nayan</small><ArrowUpRight/></a></div></section>

    <section className="contact section-shell" id="contact"><div className="section-kicker reveal"><span>05 — WHAT'S NEXT?</span><span>HAVE A GOOD ONE IN MIND?</span></div><div className="contact-content reveal">
      <div className="contact-intro"><p className="eyebrow">LET'S MAKE IT HAPPEN</p><h2>Have a project<br />in <em>mind?</em></h2><p className="contact-lead">Have an idea, a question, or an opportunity? Let's turn it into something thoughtful, useful, and memorable.</p><a className="contact-cta" href="mailto:hello@shreeramwagle.com.np">START A CONVERSATION <ArrowUpRight size={22} /></a></div>
      <div className="contact-details">
        <div className="contact-detail"><span>EMAIL</span><a href="mailto:hello@shreeramwagle.com.np">hello@shreeramwagle.com.np <ArrowUpRight size={15}/></a></div>
        <div className="contact-detail"><span>LOCATION</span><strong>NEPAL · GMT +5:45</strong></div>
        <div className="contact-detail"><span>AVAILABILITY</span><strong><i/> OPEN TO COLLABORATION</strong></div>
        <div className="contact-social-row"><span>ELSEWHERE ON THE INTERNET</span><div><a href="https://www.instagram.com/krazyy.nayan/" target="_blank" rel="noreferrer">INSTAGRAM <ArrowUpRight size={13}/></a><a href="https://www.tiktok.com/@nocetra.cc" target="_blank" rel="noreferrer">TIKTOK <ArrowUpRight size={13}/></a></div></div>
      </div>
    </div><footer><a className="brand" href="#home">shreeramwagle<span>.com.np</span></a><div className="socials"><a href="https://www.facebook.com/nayan.wagle.2025" target="_blank" rel="noreferrer" aria-label="Facebook"><Facebook /></a><a href="https://www.instagram.com/krazyy.nayan/" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram /></a><a href="mailto:hello@shreeramwagle.com.np" aria-label="Email"><Mail /></a></div><span>© 2026 SHREERAM WAGLE. ALL RIGHTS RESERVED.</span><a className="back-top" href="#home">BACK TO TOP ↑</a></footer></section>
  </main>}</>;
}

createRoot(document.getElementById('root')).render(<App />);
